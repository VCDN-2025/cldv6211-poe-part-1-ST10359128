﻿namespace EventEaseApp.Models
{
    public class Booking
    {
        public int BookingID { get; set; }

        public int VenueID { get; set; }
        public Venue Venue { get; set; }

        public int EventID { get; set; }
        public Event Event { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string Status { get; set; }
    }
}
